---
name: Technical Tropical Guide
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf1'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fa'
  on-surface: '#111c2c'
  on-surface-variant: '#43474d'
  inverse-surface: '#263142'
  inverse-on-surface: '#ebf1ff'
  outline: '#73777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#436182'
  primary: '#002542'
  on-primary: '#ffffff'
  primary-container: '#1b3b5a'
  on-primary-container: '#87a5ca'
  inverse-primary: '#abc9ef'
  secondary: '#9a442d'
  on-secondary: '#ffffff'
  secondary-container: '#fc9174'
  on-secondary-container: '#742814'
  tertiary: '#232421'
  on-tertiary: '#ffffff'
  tertiary-container: '#393937'
  on-tertiary-container: '#a3a29f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#abc9ef'
  on-primary-fixed: '#001d35'
  on-primary-fixed-variant: '#2a4968'
  secondary-fixed: '#ffdbd2'
  secondary-fixed-dim: '#ffb4a1'
  on-secondary-fixed: '#3c0800'
  on-secondary-fixed-variant: '#7c2e19'
  tertiary-fixed: '#e4e2de'
  tertiary-fixed-dim: '#c8c6c3'
  on-tertiary-fixed: '#1b1c1a'
  on-tertiary-fixed-variant: '#474744'
  background: '#f9f9ff'
  on-background: '#111c2c'
  surface-variant: '#d8e3fa'
typography:
  headline-xl:
    fontFamily: Merriweather
    fontSize: 48px
    fontWeight: '900'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Merriweather
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Merriweather
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Merriweather
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.8'
  body-md:
    fontFamily: Merriweather
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  code-block:
    fontFamily: Geist Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1100px
  gutter: 24px
---

## Brand & Style
This design system merges the rigorous, structured nature of technical documentation with the warmth of a coastal sanctuary. It is designed specifically for a GitHub guide, targeting developers who value both clarity and a high-quality reading experience. 

The style is **Modern Corporate** with a **Tactile** twist. It avoids the coldness of typical documentation by using a sophisticated, organic palette and generous white space. The interface should feel like a premium physical handbook—authoritative yet approachable. Visual interest is generated through high-quality typography and subtle depth rather than heavy ornamentation.

## Colors
The palette is grounded in the deep, intelligent tones of the ocean and the inviting warmth of the shore.

*   **Primary (Deep Sea Blue):** Used for primary navigation, headings, and core structural elements. It provides the "Technical" weight.
*   **Secondary (Coral):** Reserved for high-visibility actions, active states, and critical highlights. It provides the "Tropical" energy.
*   **Tertiary (Sand):** The foundation for the background and surface containers, providing a soft, low-strain reading environment compared to pure white.
*   **Neutral:** A range of blues and grays used for body text and secondary metadata.

Color should be applied with a "less is more" philosophy to maintain professional clarity.

## Typography
The typography system relies on **Merriweather** to establish a literary, authoritative tone. This choice treats technical documentation as a narrative. 

To balance the serif's warmth, **Geist** (Sans and Mono) is introduced for UI labels and code snippets. This provides the "Technical" precision required for a GitHub-centric product. 

- Use **Headline XL** only for page titles.
- Use **Body LG** for long-form reading to ensure maximum legibility.
- **Geist Mono** is mandatory for all Git commands and code blocks to ensure character alignment and a familiar developer experience.

## Layout & Spacing
The layout follows a **Fixed Grid** model for desktop to ensure the reading line-length remains optimal (approx. 70-80 characters).

- **Desktop:** 12-column grid centered in the viewport.
- **Mobile:** Single column with 16px side margins.
- **Rhythm:** Vertical spacing should be generous. Sections are separated by the `xl` unit to give the content "room to breathe," mimicking the openness of a tropical landscape.
- **Safe Zones:** Always maintain a minimum of `md` padding within cards and containers to prevent the literary type from feeling cramped.

## Elevation & Depth
Depth is achieved through **Tonal Layers** and extremely soft **Ambient Shadows**. 

- **Level 0 (Floor):** The "Sand" background (`#f5f3ef`).
- **Level 1 (Cards/Content):** Pure white surfaces with a subtle 1px border in a darkened sand tone.
- **Level 2 (Popovers/Modals):** White surfaces with a soft, diffused shadow: `0 10px 30px rgba(27, 59, 90, 0.08)`. The shadow is tinted with the Primary color to maintain palette harmony.

Avoid heavy blacks or harsh drop-shadows; the goal is a gentle, natural lift.

## Shapes
The design system uses a consistent **12px (0.75rem)** corner radius for most containers, providing a friendly, approachable feel that contrasts with the sharp "technical" nature of code.

- **Standard (12px):** Buttons, cards, and input fields.
- **Large (24px):** Major layout containers and hero sections.
- **Small (4px):** Code inline-tags and small UI markers.

## Components

### Code Snippets
Code blocks must have a dark background using the Primary color (`#1b3b5a`) to contrast with the light page. Syntax highlighting should use the Secondary Coral and soft teals. Include a "Copy" button in the top right corner using a ghost-button style.

### Multi-step Progress Bars
A horizontal track using a faded version of the Primary color. Completed steps are indicated by a Coral circle with a white checkmark. The "Active" step is a Primary color circle with a Coral outer ring. Labels use the `label-sm` typography style.

### Call-to-Action (CTA) Buttons
- **Primary:** Coral background with white text. 12px rounded corners. On hover, darken the Coral slightly.
- **Secondary:** Deep Sea Blue outline (2px) with Primary colored text. 
- **Transitions:** All buttons must have a 200ms ease-in-out transition on hover.

### Cards
Cards use a white background on the Sand floor. They feature a 12px border radius and a 1px stroke in `#e2e0db`. Use them to group GitHub repository information or guide chapters.

### Input Fields
Soft white backgrounds with a 1px border. Focus state uses a 2px Coral border with no glow.