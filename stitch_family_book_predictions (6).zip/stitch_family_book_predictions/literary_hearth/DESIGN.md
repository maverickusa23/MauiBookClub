---
name: Literary Hearth
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#43474d'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#73777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#436182'
  primary: '#002542'
  on-primary: '#ffffff'
  primary-container: '#1b3b5a'
  on-primary-container: '#87a5ca'
  inverse-primary: '#abc9ef'
  secondary: '#45664b'
  on-secondary: '#ffffff'
  secondary-container: '#c4e9c7'
  on-secondary-container: '#4a6a4f'
  tertiary: '#371d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#51320e'
  on-tertiary-container: '#c79a6d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#abc9ef'
  on-primary-fixed: '#001d35'
  on-primary-fixed-variant: '#2a4968'
  secondary-fixed: '#c7ecca'
  secondary-fixed-dim: '#abd0af'
  on-secondary-fixed: '#02210c'
  on-secondary-fixed-variant: '#2e4e35'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#eebd8e'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#61401b'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
typography:
  display-lg:
    fontFamily: Merriweather
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Merriweather
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Merriweather
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Merriweather
    fontSize: 24px
    fontWeight: '400'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  margin-mobile: 20px
  margin-desktop: 64px
  gutter: 24px
  max-width: 1280px
---

## Brand & Style

The brand personality of the design system is intellectual yet nurturing—a digital sanctuary for families to explore literature together. It evokes the feeling of a sun-drenched private library: quiet, respectful, and deeply warm. The target audience spans from young children just beginning their reading journey to parents and grandparents, requiring a UI that is both sophisticated and highly legible.

The visual style is a blend of **Minimalism** and **Tactile** design. We use generous whitespace to honor the text, combined with soft physical metaphors—like the subtle texture of aged paper and the weight of a hardbound book—to make the digital experience feel grounded and permanent. The emotional response should be one of "cozy focus," encouraging long-form reading and thoughtful collaborative discussion.

## Colors

The palette is inspired by traditional bookbinding and natural materials. 
- **Primary (Midnight Spine):** A deep, scholarly blue used for primary navigation, titles, and high-emphasis elements.
- **Secondary (Library Green):** A muted evergreen used for collaborative features, progress indicators, and family-specific actions.
- **Tertiary (Oxblood Leather):** Used sparingly for accents, bookmarks, and call-to-actions that require warmth.
- **Background (Aged Paper):** The primary canvas is a soft cream rather than pure white, reducing eye strain and providing a nostalgic, tactile base.

Functional colors (success, error, warning) are desaturated to maintain the "vintage" aesthetic without losing their semantic utility.

## Typography

This design system employs a classic serif/sans-serif pairing to balance literary tradition with modern accessibility. 

**Merriweather** is our primary voice for headlines and book titles. Its high x-height and sturdy serifs make it exceptionally readable on screens while providing the "bookish" authority the brand requires. 

**Be Vietnam Pro** is used for all UI elements, body text, and metadata. Its contemporary, friendly letterforms provide a clear contrast to the serif headings, ensuring that administrative tasks (like setting a reading goal) feel effortless and accessible for all age groups. 

For user predictions and "marginalia," we use a slightly italicized version of the body font to mimic the feel of handwritten notes in a book's gutter.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model that centers content, mimicking the focused margins of a printed page. 

- **Desktop:** A 12-column grid with wide 64px margins creates a "reading room" atmosphere.
- **Mobile:** A single-column flow with 20px margins ensures book covers and text remain the heroes of the screen.
- **Rhythm:** We use an 8px base unit. Component padding is generous (often 24px or 32px) to prevent the UI from feeling "crowded" or "app-like," favoring the spaciousness of a well-edited manuscript.

Collaborative elements, such as family predictions, are often offset or "tucked" into sidebars to represent marginalia without interrupting the flow of book details.

## Elevation & Depth

We avoid the "floating" shadows of modern SaaS apps. Instead, the design system uses **Tonal Layers** and **Ambient, Warm Shadows** to create a sense of physical stacking.

- **Level 0 (The Table):** The main background (`neutral_color_hex`).
- **Level 1 (The Page):** Surfaces like cards and containers use `surface_paper_hex` with a 1px soft stroke in a slightly darker tan.
- **Level 2 (The Bookmark):** Elements that require immediate attention (like a "Currently Reading" block) use a very soft, diffused shadow with a hint of umber (#2C1E0F) at 5% opacity.

The goal is to make elements feel as though they are resting on each other, rather than hovering in digital space.

## Shapes

The shape language is defined by **soft, organic roundedness**. Sharp corners are avoided to maintain the friendly, family-oriented tone. 

Book covers are given a `rounded-lg` (1rem) treatment to mimic the softened corners of a well-loved volume. Buttons and input fields use a standard `0.5rem` radius. Interactive "chips" (used for book genres or family members) use a semi-pill shape to distinguish them from more formal content blocks.

## Components

### Buttons
Primary buttons are solid `primary_color_hex` with white text. Secondary buttons use a "ghost" style with a `tertiary_color_hex` border, feeling like a stamped leather mark.

### Cards (The "Book Block")
Book cards are the centerpiece. They feature a high-aspect-ratio image of the cover, a subtle 1px inner border to simulate depth, and the title in Merriweather. 

### Predictions & Notes
User-generated predictions are styled as "Sticky Notes" or "Marginalia." These use a slightly different tint (a pale yellow-cream) and a faint "paper-edge" texture. They are always accompanied by a small family member avatar to emphasize the collaborative nature.

### Input Fields
Inputs are minimalist, using only a bottom border that thickens on focus, evocative of the lines on a piece of stationery.

### Progress Indicators
Reading progress is shown via a "Thread" metaphor—a thin, secondary-colored line that looks like a silk page-marker ribbon.